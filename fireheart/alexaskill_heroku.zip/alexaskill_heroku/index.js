
// // views is directory for all template files
// app.set('views', __dirname + '/views');
// app.set('view engine', 'ejs');



// app.listen(app.get('port'), function() {
// 	console.log('Node app is running on port', app.get('port'));
// });





var FIREBASE_URL_BASE = "https://echo-firebase.firebaseio-demo.com/";


var Firebase = require('firebase');
var heart = new Firebase(FIREBASE_URL_BASE + 'sensor/heart');
var dice = new Firebase(FIREBASE_URL_BASE + 'sensor/dice');


var heart_rate;


var express     = require('express'),
    AlexaSkills = require('alexa-skills'),
    app         = express(),
    port        = process.env.PORT || 8080,

    alexa = new AlexaSkills({
        express: app, // required
        route: "/alexa", // optional, defaults to "/"
        applicationId: "amzn1.echo-sdk-ams.app.54d3f7f9-33c2-42a7-b4d7-fab98795117c" // optional, but recommended
    });


heart.on('value', function(snapshot){
	heart_rate = snapshot.val();
	console.log("heart_rate", heart_rate);
});


alexa.launch(function(req, res) {

	console.log("alexa launch");
    var phrase = "Hi! Do you want to know your heart frequency?";
    var options = {
        shouldEndSession: false,
        outputSpeech: phrase,
        reprompt: "What was that?"
    };

    alexa.send(req, res, options);
});

alexa.intent('HeartIntent', function(req, res, slots) {
	console.log("alexa HeartIntent");
    console.log(slots);

	var phrase = "";
	if (heart_rate && heart_rate > 0) {
		phrase = "Your heart frequency is " + heart_rate + " beats per minute.";
	} else {
		phrase = "I could't find your heart frequency. Make sure you are near the sensor.";
	}
	var options = {
		shouldEndSession: true,
		outputSpeech: phrase,
		card: alexa.buildCard("Heart Rate", phrase)
	};

	alexa.send(req, res, options);
    
});

alexa.ended(function(req, res, reason) {
	console.log("alexa ended");
    console.log(reason);
});


// app.get('/', function(request, response) {
// 	response.send('Oi');
// });


app.use(express.static(__dirname + '/public'));

app.listen(port);

